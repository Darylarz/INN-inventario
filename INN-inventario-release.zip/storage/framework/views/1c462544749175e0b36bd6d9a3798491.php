<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <h2 class="text-xl font-semibold mb-4">Inventario</h2>

    
    <?php if(isset($totalUnits)): ?>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      <div class="bg-white dark:bg-gray-800 rounded shadow p-4">
        <div class="text-sm text-gray-600 dark:text-gray-300">Unidades totales</div>
        <div class="text-3xl font-bold text-gray-900 dark:text-gray-100 mt-1"><?php echo e(number_format((int)($totalUnits ?? 0))); ?></div>
      </div>
      <div class="md:col-span-2 bg-white dark:bg-gray-800 rounded shadow p-4">
        <div class="text-sm text-gray-600 dark:text-gray-300 mb-2">Unidades por categoría</div>
        <div class="flex flex-wrap gap-2">
          <?php $__empty_1 = true; $__currentLoopData = ($totalsByType ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $sum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-800 dark:bg-blue-900/40 dark:text-blue-200 text-sm">
              <span class="font-medium"><?php echo e($type ?: 'Sin categoría'); ?></span>
              <span class="inline-flex items-center justify-center rounded bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100 text-xs font-semibold px-2 py-0.5"><?php echo e((int)$sum); ?></span>
            </span>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <span class="text-sm text-gray-500 dark:text-gray-400">Sin datos de categorías</span>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="text-green-600 mb-3"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(($lowStockItems ?? collect())->count()): ?>
      <div class="mb-4 rounded border border-yellow-300 bg-yellow-50 text-yellow-800 p-4">
        <div class="font-semibold mb-2">Alerta: stock bajo en <?php echo e(($lowStockItems ?? collect())->count()); ?> artículo(s)</div>
        <ul class="list-disc pl-5 space-y-1">
          <?php $__currentLoopData = $lowStockItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <?php echo e($i->item_type ?? 'Artículo'); ?> —
              <?php echo e(trim(($i->brand ?? '').' '.($i->model ?? ''))); ?>

              <?php echo e($i->tool_name ? ' · '.$i->tool_name : ''); ?>

              <?php echo e($i->printer_model ? ' · '.$i->printer_model : ''); ?>

              <?php echo e($i->material_type ? ' · '.$i->material_type : ''); ?>

              (<?php echo e((int)($i->quantity ?? 0)); ?>)
              <a href="<?php echo e(route('inventory.show', $i->id)); ?>" class="underline">ver</a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <div class="space-y-3 mb-4">
      <div class="flex items-center gap-3">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('articulo agregar')): ?>
          <a href="<?php echo e(route('inventory.create')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">+ Nuevo Artículo</a>
        <?php endif; ?>
      </div>

      <form action="<?php echo e(route('inventory.index')); ?>" method="GET" class="flex-1 flex items-center gap-2">
        <input type="hidden" name="page" value="1">
        <input type="text" name="search" value="<?php echo e($search ?? request('search')); ?>" placeholder="Buscar por marca, modelo, nro de serie, bien nacional, tipo, modelo impresora, capacidad y generación" class="w-full px-3 py-2 border rounded">
        <button class="px-4 py-2 bg-gray-800 text-white rounded hover:bg-gray-900">Buscar</button>
        <?php if(!empty($search) || filled(request('search'))): ?>
          <a href="<?php echo e(route('inventory.index')); ?>" class="px-3 py-2 text-gray-700 underline">Limpiar</a>
        <?php endif; ?>
      </form>
    </div>

    <?php
      // Obtener la colección de la página actual para agrupar por tipo sin afectar la paginación
      $pageItems = $inventories->getCollection();
      $pcItems = $pageItems->filter(fn($i) => in_array($i->item_type, ['PC','Hardware']));
      $consumableItems = $pageItems->filter(fn($i) => $i->item_type === 'Consumible');
      $toolItems = $pageItems->filter(fn($i) => $i->item_type === 'Herramienta');
    ?>

    
    <h3 class="text-lg font-semibold mt-6 mb-2">PC / Hardware</h3>
    <table class="table-auto border-collapse border border-gray-300 w-full">
      <thead class="bg-gray-100">
        <tr>
          <th class="border px-3 py-2">Tipo</th>
          <th class="border px-3 py-2">Marca</th>
          <th class="border px-3 py-2">Modelo</th>
          <th class="border px-3 py-2">Capacidad</th>
          <th class="border px-3 py-2">Tipo (componente)</th>
          <th class="border px-3 py-2">Generación</th>
          <th class="border px-3 py-2">Número de serie</th>
          <th class="border px-3 py-2">Bien Nacional</th>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario crear')): ?>
            <th class="border px-3 py-2">Acciones</th>
          <?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $pcItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="hover:bg-gray-50">
            <td class="border px-3 py-2"><?php echo e($item->item_type); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->brand ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->model ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->capacity ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->type ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->generation ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->serial_number ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->national_asset_tag ?? '-'); ?></td>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario crear')): ?>
              <td class="border px-3 py-2">
                <a href="<?php echo e(route('inventory.show', $item->id)); ?>" class="inline-block px-2 py-1 rounded bg-gray-100 hover:bg-gray-200 text-gray-800 mr-2">Detalle</a>
                <a href="<?php echo e(route('inventory.entrada.create', $item->id)); ?>" class="inline-block px-2 py-1 rounded bg-green-600 hover:bg-green-700 text-white mr-2">Entrada</a>
                <a href="<?php echo e(route('inventory.salida.create', $item->id)); ?>" class="inline-block px-2 py-1 rounded bg-red-600 hover:bg-red-700 text-white mr-2">Salida</a>
                <a href="<?php echo e(route('inventory.edit', $item->id)); ?>" class="text-blue-600 mr-2">Editar</a>
                <form action="<?php echo e(route('inventory.disable', $item->id)); ?>" method="POST" class="inline" onsubmit="var r = prompt('Motivo de desincorporación (opcional):'); if (r === null) { return false; } this.querySelector('input[name=disabled_reason]').value = r; return confirm('¿Desincorporar artículo?');">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="disabled_reason" value="">
                  <button class="text-yellow-600 mr-2">Desincorporar</button>
                </form>
                
              </td>
            <?php endif; ?>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="9" class="text-center py-3 text-gray-500">Sin resultados</td></tr>
        <?php endif; ?>
      </tbody>
    </table>

    
    <h3 class="text-lg font-semibold mt-8 mb-2">Consumibles</h3>
    <table class="table-auto border-collapse border border-gray-300 w-full">
      <thead class="bg-gray-100">
        <tr>
          <th class="border px-3 py-2">Marca</th>
          <th class="border px-3 py-2">Modelo</th>
          <th class="border px-3 py-2">Color</th>
          <th class="border px-3 py-2">Modelo impresora</th>
          <th class="border px-3 py-2">Material / Categoría</th>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario crear')): ?>
            <th class="border px-3 py-2">Acciones</th>
          <?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $consumableItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="hover:bg-gray-50">
            <td class="border px-3 py-2"><?php echo e($item->brand ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->model ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->color ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->printer_model ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->material_type ?? '-'); ?></td>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario crear')): ?>
              <td class="border px-3 py-2">
                <a href="<?php echo e(route('inventory.show', $item->id)); ?>" class="inline-block px-2 py-1 rounded bg-gray-100 hover:bg-gray-200 text-gray-800 mr-2">Detalle</a>
                <a href="<?php echo e(route('inventory.entrada.create', $item->id)); ?>" class="inline-block px-2 py-1 rounded bg-green-600 hover:bg-green-700 text-white mr-2">Entrada</a>
                <a href="<?php echo e(route('inventory.salida.create', $item->id)); ?>" class="inline-block px-2 py-1 rounded bg-red-600 hover:bg-red-700 text-white mr-2">Salida</a>
                <a href="<?php echo e(route('inventory.edit', $item->id)); ?>" class="text-blue-600 mr-2">Editar</a>
                <form action="<?php echo e(route('inventory.disable', $item->id)); ?>" method="POST" class="inline" onsubmit="var r = prompt('Motivo de desincorporación (opcional):'); if (r === null) { return false; } this.querySelector('input[name=disabled_reason]').value = r; return confirm('¿Desincorporar artículo?');">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="disabled_reason" value="">
                  <button class="text-yellow-600 mr-2">Desincorporar</button>
                </form>
                
              </td>
            <?php endif; ?>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="6" class="text-center py-3 text-gray-500">Sin resultados</td></tr>
        <?php endif; ?>
      </tbody>
    </table>

    
    <h3 class="text-lg font-semibold mt-8 mb-2">Herramientas</h3>
    <table class="table-auto border-collapse border border-gray-300 w-full">
      <thead class="bg-gray-100">
        <tr>
          <th class="border px-3 py-2">Marca</th>
          <th class="border px-3 py-2">Modelo</th>
          <th class="border px-3 py-2">Nombre herramienta</th>
          <th class="border px-3 py-2">Tipo herramienta</th>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario crear')): ?>
            <th class="border px-3 py-2">Acciones</th>
          <?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $toolItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="hover:bg-gray-50">
            <td class="border px-3 py-2"><?php echo e($item->brand ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->model ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->tool_name ?? '-'); ?></td>
            <td class="border px-3 py-2"><?php echo e($item->tool_type ?? '-'); ?></td>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario crear')): ?>
              <td class="border px-3 py-2">
                <a href="<?php echo e(route('inventory.show', $item->id)); ?>" class="inline-block px-2 py-1 rounded bg-gray-100 hover:bg-gray-200 text-gray-800 mr-2">Detalle</a>
                <a href="<?php echo e(route('inventory.entrada.create', $item->id)); ?>" class="inline-block px-2 py-1 rounded bg-green-600 hover:bg-green-700 text-white mr-2">Entrada</a>
                <a href="<?php echo e(route('inventory.salida.create', $item->id)); ?>" class="inline-block px-2 py-1 rounded bg-red-600 hover:bg-red-700 text-white mr-2">Salida</a>
                <a href="<?php echo e(route('inventory.edit', $item->id)); ?>" class="text-blue-600 mr-2">Editar</a>
                <form action="<?php echo e(route('inventory.disable', $item->id)); ?>" method="POST" class="inline" onsubmit="var r = prompt('Motivo de desincorporación (opcional):'); if (r === null) { return false; } this.querySelector('input[name=disabled_reason]').value = r; return confirm('¿Desincorporar artículo?');">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="disabled_reason" value="">
                  <button class="text-yellow-600 mr-2">Desincorporar</button>
                </form>
                
              </td>
            <?php endif; ?>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="5" class="text-center py-3 text-gray-500">Sin resultados</td></tr>
        <?php endif; ?>
      </tbody>
    </table>

    <div class="mt-6">
      <?php echo e($inventories->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/daryl/programacion/INN/INN-inventario/INN-inventario/resources/views/inventory/index.blade.php ENDPATH**/ ?>