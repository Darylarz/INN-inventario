<?php $__env->startSection('content'); ?>
<div class="max-w-md mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
  <h2 class="text-2xl font-semibold mb-4 text-center text-gray-900 dark:text-white">Iniciar sesión</h2>

  <?php if(session('error')): ?>
    <div class="text-sm text-red-600 mb-4"><?php echo e(session('error')); ?></div>
  <?php endif; ?>

  <form method="POST" action="<?php echo e(url('/login')); ?>" class="space-y-4">
    <?php echo csrf_field(); ?>

    <div>
      <label class="block text-sm mb-1 text-gray-700 dark:text-gray-300">Email</label>
      <input name="email" type="email" value="<?php echo e(old('email')); ?>" required class="w-full px-3 py-2 border rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white" />
      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-sm text-red-600 mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
      <label class="block text-sm mb-1 text-gray-700 dark:text-gray-300">Contraseña</label>
      <input name="password" type="password" required class="w-full px-3 py-2 border rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white" />
      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-sm text-red-600 mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
      <button type="submit" class="w-full px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Entrar</button>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/daryl/programacion/INN/INN-inventario/INN-inventario/resources/views/auth/login.blade.php ENDPATH**/ ?>