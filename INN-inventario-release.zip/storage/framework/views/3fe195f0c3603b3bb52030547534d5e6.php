<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6 bg-white rounded shadow">
    <h2 class="text-xl font-semibold mb-4">Crear artículo</h2>

    <form id="inventory-form" action="<?php echo e(route('inventory.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-4">
            <label class="font-semibold">Tipo de artículo</label>
            <select id="item_type" name="item_type" class="w-full px-3 py-2 border rounded">
                <option value="">-- seleccionar --</option>
                <?php
                    $labels = ['PC'=>'PC','Hardware'=>'Hardware','Consumible'=>'Consumible','Herramienta'=>'Herramienta'];
                ?>
                <?php $__currentLoopData = $tipoInventario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type->name); ?>" <?php echo e(old('item_type') == $type->name ? 'selected' : ''); ?>>
                        <?php echo e($labels[$type->name] ?? $type->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['item_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    <input type="hidden" id="hidden_type" name="type">


        
        <div id="field-brand" class="mb-3" style="display: none;">
            <label>Marca (si aplica)</label>
            <input type="text" name="brand" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('brand')); ?>">
            <?php $__errorArgs = ['brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div id="field-model" class="mb-3" style="display: none;">
            <label>Modelo (si aplica)</label>
            <input type="text" name="model" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('model')); ?>">
            <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div id="pc-fields" style="display:none;">
            <div class="mb-3">
                <label>Nombre</label>
                <input type="text" name="name" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('name')); ?>">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label>Capacidad (si aplica)</label>
                <input type="text" name="capacity" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('capacity')); ?>">
            </div>

            <div class="mb-3">
                <label>Tipo (si aplica)</label>
                <input type="text" name="type" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('type')); ?>">
            </div>

            <div class="mb-3">
                <label>Generación (si aplica)</label>
                <input type="text" name="generation" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('generation')); ?>">
            </div>

            <div class="mb-3">
                <label>Número de serie (si aplica)</label>
                <input type="text" name="serial_number" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('serial_number')); ?>">
            </div>

            <div class="mb-3">
                <label>Bien nacional (si aplica)</label>
                <input type="text" name="national_asset_tag" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('national_asset_tag')); ?>">
            </div>
        </div>

        
        <div id="consumible-fields" style="display:none;">
            <div class="mb-3">
                <label>Nombre</label>
                <input type="text" name="name" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('name')); ?>">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label>Color</label>
                <input type="text" name="color" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('color')); ?>">
            </div>

            <div class="mb-3">
                <label>Modelo de impresora (si aplica)</label>
                <input type="text" name="printer_model" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('printer_model')); ?>">
            </div>

            <div class="mb-3">
                <label>Material / Categoría (si aplica)</label>
                <input type="text" name="material_type" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('material_type')); ?>">
            </div>

            <div class="mb-3">
                <label>Número de serie (si aplica)</label>
                <input type="text" name="serial_number" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('serial_number')); ?>">
            </div>

            <div class="mb-3">
                <label>Bien nacional (si aplica)</label>
                <input type="text" name="national_asset_tag" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('national_asset_tag')); ?>">
            </div>
        </div>

        
        <div id="herramienta-fields" style="display:none;">

            <div class="mb-3">
                <label>Nombre</label>
                <input type="text" name="tool_name" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('tool_name')); ?>">
            </div>

            <div class="mb-3">
                <label>Tipo herramienta (si aplica)</label>
                <input type="text" name="tool_type" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('tool_type')); ?>">
            </div>

            <div class="mb-3">
                <label>Número de serie (si aplica)</label>
                <input type="text" name="serial_number" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('serial_number')); ?>">
            </div>

            <div class="mb-3">
                <label>Bien nacional (si aplica)</label>
                <input type="text" name="national_asset_tag" class="w-full px-3 py-2 border rounded" value="<?php echo e(old('national_asset_tag')); ?>">
            </div>
        </div>

        <div class="mt-4">
            <button id="submit-btn" type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">Crear</button>
        </div>
    </form>
</div>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const sel = document.getElementById('item_type');
    const brand = document.getElementById('field-brand');
    const model = document.getElementById('field-model');
    const pcFields = document.getElementById('pc-fields');
    const consumibleFields = document.getElementById('consumible-fields');
    const herramientaFields = document.getElementById('herramienta-fields');

    function updateFields() {
        const v = (sel.value || '').toLowerCase();
        // hide all by default
        brand.style.display = 'none';
        model.style.display = 'none';
        pcFields.style.display = 'none';
        consumibleFields.style.display = 'none';
        herramientaFields.style.display = 'none';

        if (!v) return;

        // show common
        brand.style.display = '';
        model.style.display = '';

        if (v === 'pc' || v === 'hardware') {
            pcFields.style.display = '';
        } else if (v === 'consumible' || v === 'consumible') {
            consumibleFields.style.display = '';
        } else if (v === 'herramienta' || v === 'herramienta') {
            herramientaFields.style.display = '';
        }
    }

    sel.addEventListener('change', updateFields);

    // run on load in case old() exists
    updateFields();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/daryl/programacion/INN/INN-inventario/INN-inventario/resources/views/inventory/create.blade.php ENDPATH**/ ?>