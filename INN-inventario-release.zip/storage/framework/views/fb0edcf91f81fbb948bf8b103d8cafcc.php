<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto">
  <h1 class="text-2xl font-semibold mb-4 text-gray-800 dark:text-gray-100">Entrada de artículo</h1>

  <div class="bg-white dark:bg-gray-800 shadow rounded p-4 mb-4">
    <div class="text-sm text-gray-600 dark:text-gray-300">Artículo</div>
    <div class="font-medium text-gray-900 dark:text-gray-100"><?php echo e($inventory->brand); ?> <?php echo e($inventory->model); ?> (ID: <?php echo e($inventory->id); ?>)</div>
    <div class="mt-2 text-sm text-gray-600 dark:text-gray-300">Stock actual: <span class="font-semibold"><?php echo e($inventory->quantity ?? 0); ?></span></div>
  </div>

  <form method="POST" action="<?php echo e(route('inventory.entrada.store', $inventory)); ?>" class="bg-white dark:bg-gray-800 shadow rounded p-4 space-y-4">
    <?php echo csrf_field(); ?>
    <div>
      <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Cantidad a ingresar</label>
      <input type="number" name="quantity" min="1" required class="mt-1 w-full rounded border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100" value="<?php echo e(old('quantity', 1)); ?>">
      <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Nota (opcional)</label>
      <input type="text" name="note" maxlength="255" class="mt-1 w-full rounded border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100" value="<?php echo e(old('note')); ?>">
      <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-sm text-red-600 mt-1"><?php echo e($message); ?></p>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="flex items-center justify-end gap-2">
      <a href="<?php echo e(route('inventory.show', $inventory)); ?>" class="px-4 py-2 rounded bg-gray-100 hover:bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-100 dark:hover:bg-gray-600">Cancelar</a>
      <button type="submit" class="px-4 py-2 rounded bg-green-600 hover:bg-green-700 text-white">Registrar entrada</button>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/daryl/programacion/INN/INN-inventario/INN-inventario/resources/views/inventory/entrada.blade.php ENDPATH**/ ?>