@extends('layouts.app')

@section('content')
<div class="container mx-auto p-6">
  <div class="flex items-center justify-between mb-4">
    <h1 class="text-xl font-semibold text-gray-900 dark:text-gray-100">Ubicaciones</h1>
    <a href="{{ route('locations.create') }}" class="px-4 py-2 rounded bg-blue-600 hover:bg-blue-700 text-white">Nueva ubicación</a>
  </div>

  @if(session('success'))
    <div class="mb-4 text-green-700 bg-green-50 border border-green-200 rounded p-3">{{ session('success') }}</div>
  @endif

  <div class="bg-white dark:bg-gray-800 rounded shadow overflow-hidden">
    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
      <thead class="bg-gray-50 dark:bg-gray-700">
        <tr>
          <th class="px-4 py-2 text-left text-xs font-medium text-gray-600 dark:text-gray-200 uppercase tracking-wider">ID</th>
          <th class="px-4 py-2 text-left text-xs font-medium text-gray-600 dark:text-gray-200 uppercase tracking-wider">Nombre</th>
          <th class="px-4 py-2 text-left text-xs font-medium text-gray-600 dark:text-gray-200 uppercase tracking-wider">Código</th>
          <th class="px-4 py-2 text-left text-xs font-medium text-gray-600 dark:text-gray-200 uppercase tracking-wider">Descripción</th>
          <th class="px-4 py-2 text-left text-xs font-medium text-gray-600 dark:text-gray-200 uppercase tracking-wider">Acciones</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-800">
        @forelse($locations as $l)
        <tr>
          <td class="px-4 py-2 text-sm text-gray-800 dark:text-gray-100">{{ $l->id }}</td>
          <td class="px-4 py-2 text-sm text-gray-800 dark:text-gray-100">{{ $l->name }}</td>
          <td class="px-4 py-2 text-sm text-gray-800 dark:text-gray-100">{{ $l->code ?? '-' }}</td>
          <td class="px-4 py-2 text-sm text-gray-800 dark:text-gray-100">{{ $l->description ?? '-' }}</td>
          <td class="px-4 py-2 text-sm">
            <a href="{{ route('locations.edit', $l) }}" class="inline-block px-2 py-1 rounded bg-gray-100 hover:bg-gray-200 text-gray-800 mr-2">Editar</a>
            <form method="POST" action="{{ route('locations.destroy', $l) }}" class="inline" onsubmit="return confirm('¿Eliminar ubicación?');">
              @csrf
              @method('DELETE')
              <button class="inline-block px-2 py-1 rounded bg-red-600 hover:bg-red-700 text-white">Eliminar</button>
            </form>
          </td>
        </tr>
        @empty
        <tr>
          <td colspan="5" class="px-4 py-6 text-sm text-gray-500 dark:text-gray-300 text-center">No hay ubicaciones registradas</td>
        </tr>
        @endforelse
      </tbody>
    </table>
    <div class="px-4 py-3">{{ $locations->links() }}</div>
  </div>
</div>
@endsection
