// importa el CSS principal (Tailwind)
import '../css/app.css'